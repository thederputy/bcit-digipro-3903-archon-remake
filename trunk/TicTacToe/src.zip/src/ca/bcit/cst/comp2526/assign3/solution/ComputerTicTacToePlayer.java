package ca.bcit.cst.comp2526.assign3.solution;

import java.util.List;


public class ComputerTicTacToePlayer
    extends TicTacToePlayer
{
    public ComputerTicTacToePlayer(final String name)
    {
        super(name);
    }

    public TicTacToeLocation getMove(final TicTacToeGame game)
    {
        final List<TicTacToeLocation> moves;

        moves = game.getPossibleMoves();

        return (moves.get(0));
    }
}
